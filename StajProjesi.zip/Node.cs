﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    internal class Node
    {
        public int Row { get; set; }
        public int Col { get; set; }

        public bool IsWall { get; set; } = false;
        public bool IsStart { get; set; } = false;
        public bool IsGoal { get; set; } = false;

        public Node(int row, int col)
        {
            Row = row;
            Col = col;
        }
    }
}
